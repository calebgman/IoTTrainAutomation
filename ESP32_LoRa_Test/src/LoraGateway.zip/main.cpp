#include <Arduino.h>
#include <MFRC522.h>
#include <LoRa.h>

using namespace std;

//#define LORA_RX 1
//#define LORA_TX 1
#define RPI_GATEWAY 1

#define LORA_SS 5
#define LORA_RS 14
#define LORA_DIO 2

uint32_t loraEpochRX = 1000000;

void setup()
{

    SPI.begin();
    Serial.begin(115200);

    LoRa.setPins(LORA_SS, LORA_RS, LORA_DIO);

    if (!LoRa.begin(915E6))
    {
        Serial.println("LoRa Failed to Initialized");
    }
    else Serial.println("LoRa Successfully Initialized");

}

void loop()
{
  #ifdef LORA_TX
  if (loraEpochRX == 0)
  {
    Serial.println("Sending Testing 123");
    LoRa.beginPacket();
    LoRa.print("Testing 123");
    LoRa.endPacket();
    loraEpochRX = 1000000;
  }

  loraEpochRX--;
  #endif

  #ifdef LORA_RX
  int packetSize = LoRa.parsePacket();
  if (packetSize > 0)
  {
    String LoRaData = LoRa.readString();
    Serial.println(LoRaData);
  }
  #endif

  #ifdef RPI_GATEWAY

  //RX Forwarding to Pi

  //get packet size
  int packetSize = LoRa.parsePacket();

  //New message if larger than 0
  if (packetSize > 0)
  {
    //read message
    String LoRaData = LoRa.readString();

    //forward message to Pi
    Serial.println(LoRaData);
  }

  //TX from Pi

  //Check for message
  if (Serial.available() > 0)
  {
    int txByte = 0;
    bool complete = false;
    String packet = "";

    while (!complete)
    {
      //read from buffer
      txByte = Serial.read();

      //check for end
      if (txByte == -1)
      {
        complete = true;
        continue;
      }

      //concatenate byte to packet
      packet.concat(txByte);
    }

    //transmit Packet
    LoRa.beginPacket();
    LoRa.print(packet);
    LoRa.endPacket();

    //return OK to Pi
    Serial.println("OK");
  }

  #endif

}